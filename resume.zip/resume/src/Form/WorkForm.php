<?php
/**
 * @file
 * Contains \Drupal\resume\Form\WorkForm.
 */
namespace Drupal\resume\Form;

use Drupal\Core\Form\FormBase;
use Drupal\Core\Form\FormStateInterface;

class workForm extends FormBase {
  /**
   * {@inheritdoc}
   */
  public function getFormId() {
    return 'resume_form';
  }

  /**
   * {@inheritdoc}
   */
  public function buildForm(array $form, FormStateInterface $form_state) {

    $form['employee_name'] = array(
      '#type' => 'Download',
      '#markup'=>'Download pay slip',
      '#required' => TRUE,
    );
$is_logged_in = \Drupal::currentUser()->isAuthenticated();
        $is_oil_lab_user = \Drupal\user\Entity\User::load(\Drupal::currentUser()->id())->hasRole('oil_lab_users');

        if ($is_logged_in && $is_oil_lab_user) {

            // Get header table from Drupal database
            $query = \Drupal::database()->select('header', 'h');
            $query->addJoin('INNER', 'taxonomy_term_field_data', 'ttfd', 'h.CUSTNAME = ttfd.name');
            $query->fields('h', array('CUSTNAME', 'PSTATUS_ID', 'SAMPLE_ID', 'STATUS', 'DATE_SAMPLED', 'OWNER_REFERENCE', 'SERIALNO', 'LOCATION', 'DESCRIPTION'));
            $query->fields('ttfd', array('vid', 'name'));
            $or_group = $query->orConditionGroup()
                 ->condition('h.PSTATUS_ID', 20)
                 ->condition('h.PSTATUS_ID', 30);
            $query->condition($or_group);
            $query->orderBy('h.DATE_SAMPLED', 'DESC');
            $result = $query->execute();
                // Create the row element.
                $rows = array();
                foreach ($result as $row => $content) {
                    $customer_name = $content->CUSTNAME;
                    $sample_id = $content->SAMPLE_ID;
                    //$url = Url::fromRoute('/internal-url/sample?id='.$sample_id)->toString();     \Drupal::l('Edit', $url)
                    //$get_sample_id = filter_var($_GET[$sample_id], FILTER_SANITIZE_NUMBER_INT);
                    $rows[] = array('data' => array($customer_name, $sample_id, $content->STATUS, $content->DATE_SAMPLED, $content->OWNER_REFERENCE, $content->SERIALNO, $content->LOCATION, $content->DESCRIPTION, $content->name));
                }
                // Create the header.
                $header = array('Customer', 'Sample', 'Status', 'Sample Date', 'Owner Ref', 'Serial No', 'Location', 'Description', 'Download');
                $output = array(
                    '#theme' => 'table',    // Here you can write #type also instead of #theme.
                    '#header' => $header,
                    '#rows' => $rows
                  );
            return $output;

		}

    $form['actions']['#type'] = 'actions';
    $form['actions']['submit'] = array(
      '#type' => 'submit',
      '#value' => $this->t('Download'),
      '#button_type' => 'primary',
    );
    return $form;
  }

  /**
   * {@inheritdoc}
   */
  public function submitForm(array &$form, FormStateInterface $form_state) {

    drupal_set_message($this->t('@emp_name ,Your application is being Downloaded!', array('@emp_name' => $form_state->getValue('employee_name'))));

  }
}