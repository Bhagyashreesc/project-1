<?php
$username1=$_POST['username'];
$password1=$_POST['password'];

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "emp";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

$sql = "select password,role from emp where username='$username1'; ";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
		if($row["password"]==$password1 && $row["role"]=='admin')
		{
			header("Location:admin.php");
		}
		elseif($row["password"]==$password1 && $row["role"]=='user')
		{
			header("Location:home.html");
		}
		else
		{	
			echo "incorrect password";
			header("Location:login.html");
		}
			
} else {
			echo "user does not exist";
			header("Location:login.html");
}
?>