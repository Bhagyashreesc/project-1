<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "emp";
$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 
$sql = "select * from emp;";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    echo "<table bgcolor='seagreen'><tr><th>Username</th><th>Password</th><th>Name</th><th>Country</th><th>Bio</th><th>Role</th><th colspan='2'>Action</th></tr><br>";
    while($row = $result->fetch_assoc()) {
        echo "<tr><td>".$row["username"]."</td><td>".$row["password"]."</td><td>".$row["name"]."</td>
			  <td>".$row["country"]."</td><td>".$row["bio"]."</td><td>".$row["role"]."</td>
			  <td><a href='update.php'/>update</td><td><a href='delete.php'/></td></tr><br>";
    }
    echo "<hr><button><a href='login.html'>logout</a></button></table>";
} else {
    echo "no users";
}
$conn->close();
?>