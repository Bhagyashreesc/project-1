<?php
$servername = "localhost";
$username = "root";
$password = "root";
$dbname = "emp";

$conn = mysqli_connect($servername, $username, $password, $dbname);

if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
$sql = "SELECT * FROM emp";
$result = mysqli_query($conn, $sql);

if (mysqli_num_rows($result) > 0) {
    
	 echo   "<head>
			<style>
			.header{
				float: left;
				background-color:seagreen;
				text-align:left;
				padding: 10px;
				text-decoration: none;
				font-size: 20px; 
				width:100%;
				color:blue;
				border:1px;
				border-radius: 4px;
			}
			.header1,.header2,.header3,.header4
			{
				padding-left:20px;
				padding-right:20px;
				border:1px solid;
				background-color:LightGray;
			}
			</style>
			</head>
			<body bgcolor='yellow'>
				<div class='header'>
					<a href='capgemini.com'><img src='images/caps.png' alt='CAPGEMINI' width='100px' height='60px'/></a>
					<a class='header1' href='home.html'>Home</a>
					<a class='header2' href='contact.html'>Contact</a>
					<a class='header3' href='register.html'>Register</a>
					<a class='header4' href='admin.html'>Admin</a>
				</div>
				<hr><h3 color='blue' align='center'>USER DETAILS</h3><hr>";
		
		
    while($row = mysqli_fetch_assoc($result)) {
        echo  "<form method='post' action='operation.php'><table border='1'>
				<tr><th>USERNAME</th><th>PASSWORD</th><th>NAME</th><th>COUNTRY</th><th>BIO</th><th>ROLE</th><th colspan='2'>ACTION</th> </tr>
				<tr><td><input type='text' name='username' value=".$row['username']." readonly/></td>
				<td><input type='text' name='password' value=".$row['password']."></td>
				<td><input type='text' name='name' value=".$row['Name']."></td>
				<td><input type='text' name='country' value=".$row['Country']."></td>
				<td><input type='text' name='bio' value=".$row['Bio']."></td>
				<td><input type='text' name='role' value=".$row['Role']."></td>
				<td><input type='submit' name='update' value='update'/></td><td><input type='submit' name='delete' value='delete'/></td>
				</tr></table><br></form></body>" ;
				
    }
} else {
	//$sql = Update emp set  where username=".$row['username'].";
	//$result = mysqli_query($conn, $sql);
    echo "0 results";
}

mysqli_close($conn);
?> 