<?php
$username1=$_POST["username"];
$password1=$_POST["password"];
$confirmpassword=$_POST["cpassword"];
$name1=$_POST["name"];
$country1=$_POST["country"];
$bio1=$_POST["bio"];
$role1=$_POST["role"];


$servername="localhost";
$username="root";
$password="root";
$dbname="emp";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
$sql = "INSERT INTO emp(username,password,name,country,bio,role)
		VALUES (".'\''.$username1.'\''.",".'\''.$password1.'\''.",".'\''.$name1.'\''.",".'\''.$country1.'\''.",".'\''.$bio1.'\''.",".'\''.$role1.'\''.")";

if ($conn->query($sql) === TRUE) {
     header("Location:login.html");
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();

?>