<?php

namespace Drupal\LMS_lms\Controller;

use Drupal\Core\Controller\ControllerBase;

/**
 * Defines LMSController class.
 */
class LMSController extends ControllerBase {

  /**
   * Display the markup.
   *
   * @return array
   *   Return markup array.
   */
  public function content() {
    return [
      '#type' => 'markup',
      '#markup' => $this->t('Hello, World!'),
    ];
  }
  
   public function content1() {
    return [
      '#type' => 'markup',
      '#markup' => $this->t('Bhagya!'),
    ];
  }
  
   public function content2() {
    return [
      '#type' => 'markup',
      '#markup' => $this->t('jeevana!'),
    ];
  }

}