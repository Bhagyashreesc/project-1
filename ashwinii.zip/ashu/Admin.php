<?php
$servername = "localhost";
$username = "root";
$password = "root";
$dbname = "emp";

$conn = mysqli_connect($servername, $username, $password, $dbname);

if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

$sql = "SELECT * FROM emp";
$result = mysqli_query($conn, $sql);

if (mysqli_num_rows($result) > 0) {
    
	 echo "<hr><h3 color='blue'>USER DETAILS</h3><hr>";
	 //echo  "<table border='1' cellpadding='10px'><tr><th>USERNAME</th><th>PASSWORD</th><th>NAME</th><th>COUNTRY</th><th>BIO</th><th>ROLE</th></tr></table>";
		
		
    while($row = mysqli_fetch_assoc($result)) {
        echo  "<body bgcolor='seagreen'><form method='post' action=''><table border='1' cellpadding='5px'>
				<tr><th>USERNAME</th><th>PASSWORD</th><th>NAME</th><th>COUNTRY</th><th>BIO</th><th>ROLE</th><th colspan='2'>ACTION</th> </tr>
				<tr><td>".$row['username']."</td>
				<td>".$row['password']."</td>
				<td>".$row['Name']."</td>
				<td>".$row['Country']."</td>
				<td>".$row['Bio']."</td>
				<td>".$row['Role']."</td>
				<td><a href='update.php'>update</a>
				<td><a href='delete.php'>delete</a>
				</tr></table><br></form></body>" ;
    }
} else {
	//$sql = Update emp set  where username=".$row['username'].";
	//$result = mysqli_query($conn, $sql);
    echo "0 results";
}

mysqli_close($conn);
?> 