<?php
$servername = "localhost";
$username = "root";
$password = "root";
$dbname = "emp";

$conn = mysqli_connect($servername, $username, $password, $dbname);

if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
mysqli_select_db($conn,'emp');

if(isset($_POST['submit'])){
if($_FILES['fileToUpload']['name']){

$arrFileName = explode('.',$_FILES['fileToUpload']['name']);
if($arrFileName[1] == 'csv'){
$handle = fopen($_FILES['fileToUpload']['tmp_name'], "r");
while (($data = fgetcsv($handle, 1000, ",")) != FALSE) {

$username1 = mysqli_real_escape_string($conn,$data[0]);
$password1 = mysqli_real_escape_string($conn,$data[1]);
$name1 = mysqli_real_escape_string($conn,$data[2]);
$country1 = mysqli_real_escape_string($conn,$data[3]);
$bio1 = mysqli_real_escape_string($conn,$data[4]);
$role1= mysqli_real_escape_string($conn,$data[5]);

$import="INSERT INTO emp(username,password,name,country,bio,role)
		VALUES (".'\''.$username1.'\''.",".'\''.$password1.'\''.",".'\''.$name1.'\''.",".'\''.$country1.'\''.",".'\''.$bio1.'\''.",".'\''.$role1.'\''.")";

$result =mysqli_query($conn,$import);
echo $result;
if($result)
{
header("Location:Admin.php");
}
}
fclose($handle);
print "Import done";
}
}
}