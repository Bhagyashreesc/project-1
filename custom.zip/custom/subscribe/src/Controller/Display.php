<?php

namespace Drupal\subscriber\Controller;

use Drupal\Core\Session\AccountProxyInterface;

class Display {
  /**
   * @var AccountProxy
   */
  protected $currentUser;
  if (isset($button_url) && $button_url) {
    // TODO button as url
    $form['submit'] = array(
      '#type' => 'submit',
      '#value' => $button_text,
      '#name' => 'submit',
    );
  }
  else {
    $form['submit'] = array(
      '#type' => 'submit',
      '#value' => $button_text,
      '#name' => 'submit',
    );
  }

  public function __construct(AccountProxyInterface $currentUser) {
    $this->currentUser = $currentUser;
  };

  public function doSomething() {
    $currentUserId = $this->currentUser->id();
	$currentUserId = $this->currentUser->name();
	$currentUserId = $this->currentUser->mail();
    /* ... */
  }
}