<?php
/**
 * @file
 * Contains \Drupal\subscribe\Controller\SubscribeForm.
 */
namespace Drupal\subscribe\Controller;

use Drupal\Core\Form\FormBase;
use Drupal\Core\Form\FormStateInterface;

class SubscribeForm extends FormBase {

	/**
   * {@inheritdoc}
   */
  public function getFormId() {
    return 'subscribe_Controller';
  }

  /**
   * {@inheritdoc}
   */
  public function buildForm(array $form, FormStateInterface $form_state) {
  
  drupal_set_message($this->t('Subscribe here!'));
  
  $form['actions']['#type'] = 'actions';
    $form['actions']['submit'] = array(
      '#type' => 'submit',
      '#value' => $this->t('Save'),
      '#button_type' => 'primary',
    );
    return $form;
  }
  
  public function submitForm(array &$form, FormStateInterface $form_state) {

    drupal_set_message($this->t('Subscribe here!'));
    }

   }