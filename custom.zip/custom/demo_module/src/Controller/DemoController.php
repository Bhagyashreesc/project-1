<?php

namespace Drupal\demo_module\Controller;
use Drupal\Core\Controller\ControllerBase;

/**
 * Defines HelloController class.
 */
class DemoController extends ControllerBase{
/**
   * Display the markup.
   *
   * @return array
   *   Return markup array.
   */

    public function demo() {

        return [

                '#title' => 'Demo Module',

                '#markup' =>$this->t('This module is for demo purposes'),

            ];

    }

}